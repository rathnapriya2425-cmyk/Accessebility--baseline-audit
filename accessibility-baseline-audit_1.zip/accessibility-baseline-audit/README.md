# Accessibility Baseline & Repository Architecture Audit

A full-stack project foundation created after auditing a public service website for accessibility.
The audit findings are in [`docs/audit-report.md`](docs/audit-report.md) and drove the structure and
defaults of this repository.

## Architecture tree

```
accessibility-baseline-audit/
├── client/                  # Front end (Vite, vanilla JS, semantic HTML)
│   ├── index.html           # Landmarks, skip link, labelled search, live status region
│   ├── src/
│   │   ├── main.js          # Events + API calls
│   │   ├── render.js        # Pure DOM rendering
│   │   └── styles.css       # Focus styles, tokens
│   └── tests/               # Unit tests
├── server/                  # Back end (Node + Express)
│   ├── src/
│   │   ├── app.js           # Routes (exported for testing)
│   │   ├── data.js          # Data source (replaceable by a DB)
│   │   └── index.js         # Starts the HTTP server
│   └── tests/               # API tests (node:test)
├── docs/
│   ├── audit-report.md      # Lighthouse + keyboard audit, 5 issues, roadmap
│   ├── accessibility-audit-worksheet.csv
│   ├── architecture.md
│   └── screenshots/         # Evidence
├── tests/
│   └── e2e/                 # Planned Playwright + axe tests
├── package.json             # npm workspaces root
└── .gitignore
```

## Boundaries
| Layer | Responsibility | Must not |
|-------|----------------|----------|
| `client` | Rendering, interaction, accessibility semantics | Contain business data or import server code |
| `server` | HTTP API, validation, data access | Render HTML or know about the UI |
| `docs` | Audit evidence and decisions | Hold runtime code |
| `tests` | Cross-layer (e2e, a11y) checks | Replace unit tests in each package |

The only contract between client and server is `GET /api/services?q=` returning
`{ count, results: [{ id, name, category, description }] }`.

## Local setup
Requirements: Node.js 18+ and npm 9+.

```bash
git clone <your-repo-url>
cd accessibility-baseline-audit
npm install
npm run dev:server     # terminal 1 → http://localhost:3000/api/health
npm run dev:client     # terminal 2 → http://localhost:5173
npm test               # runs server and client tests
```

## First vertical feature slice: Service search
A user types in a labelled search box and gets a filtered list of public services.

| Layer | Work |
|-------|------|
| UI | `<search>` with `<label>`, `type="search"`, hint text, results as a list with headings |
| Behaviour | Debounced fetch; results announced via `role="status"` / `aria-live="polite"` |
| API | `GET /api/services?q=` filters the services list |
| Tests | API test for filtering; planned e2e keyboard + axe test |
| Done when | Operable by keyboard only, visible focus, Lighthouse accessibility ≥ 95, no axe violations |

## Audit-driven defaults
- Skip link and landmark regions (`header`, `nav`, `main`, `footer`)
- `lang` attribute, descriptive `<title>`, one `<h1>`
- Visible `:focus-visible` outline
- Status messages in a live region
- Plain, dependency-light front end to keep markup under control

## Next steps
1. Complete `docs/audit-report.md` with real findings and screenshots.
2. Add Playwright + axe e2e tests.
3. Add a CI workflow running `npm test` and Lighthouse CI.
