# Accessibility Audit Report

**Audited site:** <PASTE PUBLIC URL>
**Auditor:** Rathna Priya
**Date:** <DATE>
**Tools:** Lighthouse (Chrome DevTools, mobile + desktop), keyboard-only navigation pass
**Standard referenced:** WCAG 2.1 AA

## 1. Method
1. Opened the site in a clean Chrome profile (no extensions).
2. Ran Lighthouse (Accessibility category) for mobile and desktop on the home page and one inner page.
3. Unplugged the mouse and navigated with Tab, Shift+Tab, Enter, Space, Esc and arrow keys, noting focus order, visibility of focus, traps, and skipped controls.

## 2. Lighthouse scores
| Page | Device | Accessibility | Performance | Best Practices | SEO |
|------|--------|---------------|-------------|----------------|-----|
| Home | Mobile | <score> | <score> | <score> | <score> |
| Home | Desktop | <score> | <score> | <score> | <score> |
| <inner page> | Mobile | <score> | <score> | <score> | <score> |

Screenshot: `screenshots/lighthouse-summary.png`

## 3. Keyboard-only pass: summary
- Skip link present? <yes/no>
- Visible focus indicator on all controls? <yes/no, where not>
- Logical tab order? <notes>
- Keyboard traps (menus, modals, carousels)? <notes>

## 4. Issues (five required)
Priority: P1 = fix first (blocks users), P2 = important, P3 = improve.

### Issue 1: <title>
- **WCAG:** <e.g. 1.1.1 Non-text Content>
- **Where:** <page / element>
- **Evidence:** `screenshots/issue-A1.png`; Lighthouse audit: <audit name>
- **Impact:** <who is affected and how>
- **Severity / Priority:** <High / P1>
- **Remediation:** <specific fix>
- **Owner:** <role/team>

### Issue 2: <title>
(same fields)

### Issue 3: <title>
(same fields)

### Issue 4: <title>
(same fields)

### Issue 5: <title>
(same fields, may be an architecture issue, e.g. no component reuse, inline styles, no landmarks)

## 5. Remediation roadmap
| Priority | Issue | Effort | Where it is addressed in this repo |
|----------|-------|--------|-----------------------------------|
| P1 | | | e.g. `client/index.html` skip link + landmarks |

## 6. How findings shaped this repository
- <finding> → <decision in the skeleton, e.g. semantic landmarks, visible :focus-visible, aria-live status region, labelled search input>
