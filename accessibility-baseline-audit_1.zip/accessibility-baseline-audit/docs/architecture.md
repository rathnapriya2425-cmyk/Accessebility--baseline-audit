# Architecture notes

```
Browser (client) --HTTP /api--> Express API (server) --> data module (swap for DB later)
```

Rules:
- `client` never imports from `server`, and vice versa. They share only the HTTP contract.
- Accessibility concerns live in markup first (semantic HTML), CSS second, ARIA last.
- Every new UI feature needs: keyboard path, visible focus, accessible name, tested with axe.
