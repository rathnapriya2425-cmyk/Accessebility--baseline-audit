Put screenshots here. Suggested names:
- lighthouse-summary.png
- lighthouse-accessibility-details.png
- keyboard-focus-issue-1.png ... keyboard-focus-issue-N.png
- issue-A1.png ... issue-A5.png
