import express from "express";
import cors from "cors";
import { services } from "./data.js";

export const app = express();
app.use(cors());
app.use(express.json());

app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

// Vertical slice: GET /api/services?q=term
app.get("/api/services", (req, res) => {
  const q = String(req.query.q ?? "").trim().toLowerCase();
  const result = q
    ? services.filter((s) => `${s.name} ${s.category} ${s.description}`.toLowerCase().includes(q))
    : services;
  res.json({ count: result.length, results: result });
});
