// Placeholder data for the first vertical slice (service directory).
export const services = [
  { id: 1, name: "Renew driving licence", category: "Transport", description: "Apply online to renew a driving licence." },
  { id: 2, name: "Apply for a passport", category: "Identity", description: "Check eligibility and submit a passport application." },
  { id: 3, name: "Pay property tax", category: "Tax", description: "Pay municipal property tax online." },
  { id: 4, name: "Book a health appointment", category: "Health", description: "Find a clinic and book a time slot." }
];
