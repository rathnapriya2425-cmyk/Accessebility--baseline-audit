import { test } from "node:test";
import assert from "node:assert/strict";
import { app } from "../src/app.js";

async function withServer(fn) {
  const server = app.listen(0);
  const { port } = server.address();
  try { await fn(`http://localhost:${port}`); } finally { server.close(); }
}

test("health endpoint returns ok", () => withServer(async (base) => {
  const body = await (await fetch(`${base}/api/health`)).json();
  assert.equal(body.status, "ok");
}));

test("services search filters results", () => withServer(async (base) => {
  const body = await (await fetch(`${base}/api/services?q=passport`)).json();
  assert.equal(body.count, 1);
  assert.equal(body.results[0].name, "Apply for a passport");
}));
