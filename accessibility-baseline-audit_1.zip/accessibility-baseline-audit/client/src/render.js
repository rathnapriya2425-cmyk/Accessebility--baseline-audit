export function renderResults(listEl, statusEl, data) {
  listEl.replaceChildren(
    ...data.results.map((s) => {
      const li = document.createElement("li");
      const h2 = document.createElement("h2");
      h2.textContent = s.name;
      const p = document.createElement("p");
      p.textContent = `${s.category}: ${s.description}`;
      li.append(h2, p);
      return li;
    })
  );
  statusEl.textContent = `${data.count} service${data.count === 1 ? "" : "s"} found`;
}
