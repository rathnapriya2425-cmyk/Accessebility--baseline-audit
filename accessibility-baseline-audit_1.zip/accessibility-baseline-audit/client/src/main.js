import { renderResults } from "./render.js";

const input = document.getElementById("q");
const list = document.getElementById("results");
const status = document.getElementById("status");
let timer;

async function load(q = "") {
  try {
    const res = await fetch(`/api/services?q=${encodeURIComponent(q)}`);
    if (!res.ok) throw new Error(res.statusText);
    renderResults(list, status, await res.json());
  } catch {
    status.textContent = "Could not load services. Please try again.";
  }
}

input.addEventListener("input", () => {
  clearTimeout(timer);
  timer = setTimeout(() => load(input.value), 250);
});
load();
