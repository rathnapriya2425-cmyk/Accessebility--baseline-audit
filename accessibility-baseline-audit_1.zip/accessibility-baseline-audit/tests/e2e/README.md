# End-to-end tests
Planned: Playwright + @axe-core/playwright to run automated accessibility checks
on the directory page and a keyboard-only navigation test (Tab order, skip link,
search focus). Add after the first vertical slice is merged.
